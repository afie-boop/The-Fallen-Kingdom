# Asset credits and licence note

The images in this folder were prepared from reference sheets supplied by the project owner
(ruined houses, grass, sea water, beach sand, pixel characters and trees). They were cropped,
background-removed and down-scaled for the game; `characters/zombie_01.png` is a green recolour of
`char_07.png`.

**The original artists / licences were not stated.** Before publishing the game (GitHub, Play Store),
confirm you have the right to use and redistribute these images, or replace them with assets you own
or that have a clear licence. Replacing a file with another PNG of a similar size is enough - no code changes.

Generated in code (no external source): the castle, Zombie Castle and coin sprites (`scripts/pixel_art.gd`).
