class_name Hud
extends CanvasLayer
## All on-screen UI: status, mobile controls, messages, death and pause panels.
## Holds no gameplay logic - it only emits signals.

signal attack_pressed
signal interact_pressed
signal pause_pressed
signal respawn_requested
signal resume_requested
signal save_requested
signal menu_requested

const BAR_W: float = 170.0

var joystick: VirtualJoystick
var attack_button: TouchActionButton
var interact_button: TouchActionButton
var pause_button: TouchActionButton
var touch_ui: bool = false

var _root: Control
var _hp_fill: ColorRect
var _hp_label: Label
var _gold_label: Label
var _wood_label: Label
var _clock_label: Label
var _msg_label: Label
var _msg_tween: Tween
var _death_panel: Control
var _death_info: Label
var _respawn_btn: Button
var _pause_panel: Control
var _clock_t: float = 0.0
var _hint_label: Label


func _ready() -> void:
    layer = 10
    process_mode = Node.PROCESS_MODE_ALWAYS
    _root = Control.new()
    _root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_root)
    _root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build_status()
    _build_controls()
    _build_death_panel()
    _build_pause_panel()
    _root.resized.connect(_layout)
    _layout()
    _layout.call_deferred()
    GameState.wallet_changed.connect(_on_wallet_changed)
    GameState.inventory_changed.connect(_on_inventory_changed)
    GameState.kingdom_changed.connect(_refresh_resources)
    _refresh_resources()


func _unhandled_input(event: InputEvent) -> void:
    var k := event as InputEventKey
    if k != null and k.pressed and not k.echo and k.physical_keycode == KEY_ESCAPE:
        pause_pressed.emit()


func _process(delta: float) -> void:
    _clock_t -= delta
    if _clock_t > 0.0:
        return
    _clock_t = 0.25
    var total_min: int = int(GameState.time_of_day * 24.0 * 60.0)
    var hh: int = floori(total_min / 60.0)
    var mm: int = total_min % 60
    _clock_label.text = "Day %d   %02d:%02d   %s" % [GameState.day_count, hh, mm, "Night" if GameState.is_night else "Day"]


# --- public API --------------------------------------------------------------

func update_hp(hp: float, max_hp: float) -> void:
    _hp_fill.size.x = BAR_W * clampf(hp / maxf(1.0, max_hp), 0.0, 1.0)
    _hp_label.text = "HP %d / %d" % [int(ceil(hp)), int(max_hp)]


func show_message(text: String, seconds: float = 2.8) -> void:
    _msg_label.text = text
    _msg_label.modulate.a = 1.0
    if _msg_tween != null and _msg_tween.is_valid():
        _msg_tween.kill()
    _msg_tween = create_tween()
    _msg_tween.tween_interval(seconds)
    _msg_tween.tween_property(_msg_label, "modulate:a", 0.0, 0.6)


func set_interact_available(available: bool) -> void:
    interact_button.modulate.a = 1.0 if available else 0.45


func show_death(delay: float, lost_gold: int) -> void:
    _death_info.text = "You will respawn at the castle."
    if lost_gold > 0:
        _death_info.text += "\nYou lost %d Gold Coin(s)." % lost_gold
    _respawn_btn.disabled = true
    _death_panel.visible = true
    await get_tree().create_timer(delay).timeout
    if _death_panel.visible:
        _respawn_btn.disabled = false


func hide_death() -> void:
    _death_panel.visible = false


func show_pause(value: bool) -> void:
    _pause_panel.visible = value


# --- building ----------------------------------------------------------------

func _make_label(parent: Node, text: String, font_size: int) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", font_size)
    l.add_theme_color_override("font_outline_color", Color.BLACK)
    l.add_theme_constant_override("outline_size", 5)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(l)
    return l


func _make_rect(color: Color, pos: Vector2, sz: Vector2) -> ColorRect:
    var r := ColorRect.new()
    r.color = color
    r.position = pos
    r.size = sz
    r.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _root.add_child(r)
    return r


func _build_status() -> void:
    _make_rect(Color(0, 0, 0, 0.55), Vector2(12, 12), Vector2(BAR_W + 4.0, 20))
    _hp_fill = _make_rect(Color(0.8, 0.15, 0.15), Vector2(14, 14), Vector2(BAR_W, 16))
    _hp_label = _make_label(_root, "HP", 13)
    _hp_label.position = Vector2(18, 12)
    _gold_label = _make_label(_root, "Gold: 0", 17)
    _gold_label.position = Vector2(12, 36)
    _wood_label = _make_label(_root, "Wood: 0", 15)
    _wood_label.position = Vector2(12, 60)
    _clock_label = _make_label(_root, "", 16)
    _clock_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _clock_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _clock_label.offset_top = 10.0
    _msg_label = _make_label(_root, "", 18)
    _msg_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _msg_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    _msg_label.offset_top = 44.0
    _msg_label.modulate.a = 0.0


func _build_controls() -> void:
    touch_ui = DisplayServer.is_touchscreen_available() or OS.has_feature("mobile")

    joystick = VirtualJoystick.new()
    _root.add_child(joystick)
    joystick.visible = touch_ui

    attack_button = TouchActionButton.new()
    attack_button.label_text = "HIT"
    _root.add_child(attack_button)
    attack_button.visible = touch_ui
    attack_button.pressed.connect(func() -> void: attack_pressed.emit())

    interact_button = TouchActionButton.new()
    interact_button.label_text = "USE"
    _root.add_child(interact_button)
    interact_button.visible = touch_ui
    interact_button.pressed.connect(func() -> void: interact_pressed.emit())
    set_interact_available(false)

    pause_button = TouchActionButton.new()
    pause_button.label_text = "II"
    _root.add_child(pause_button)
    pause_button.pressed.connect(func() -> void: pause_pressed.emit())

    # PC: show keyboard / mouse help instead of the touch controls.
    _hint_label = _make_label(_root, "WASD / Arrows: move     Space or Left Click: attack     E: use     Esc: pause", 14)
    _hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _hint_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
    _hint_label.offset_top = -34.0
    _hint_label.offset_bottom = -8.0
    _hint_label.visible = not touch_ui


## Positions the controls from the real screen size (works for any phone/PC window).
func _layout() -> void:
    if _root == null or joystick == null:
        return
    var vs: Vector2 = _root.size
    var side: float = 36.0
    var bottom: float = 30.0
    var region_top: float = vs.y * 0.25
    joystick.position = Vector2(0.0, region_top)
    joystick.size = Vector2(vs.x * 0.5, vs.y - region_top)
    joystick.home = Vector2(side + 96.0, joystick.size.y - bottom - 96.0)
    joystick.queue_redraw()
    var a: float = 116.0
    attack_button.size = Vector2(a, a)
    attack_button.position = Vector2(vs.x - a - side, vs.y - a - bottom)
    var u: float = 88.0
    interact_button.size = Vector2(u, u)
    interact_button.position = Vector2(attack_button.position.x - u * 0.6, attack_button.position.y - u - 18.0)
    pause_button.size = Vector2(52, 52)
    pause_button.position = Vector2(vs.x - 52.0 - 14.0, 10.0)


func _make_overlay() -> Array:
    var panel := ColorRect.new()
    panel.color = Color(0, 0, 0, 0.65)
    panel.visible = false
    _root.add_child(panel)
    panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var center := CenterContainer.new()
    panel.add_child(center)
    center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    center.add_child(box)
    return [panel, box]


func _make_button(parent: Node, text: String) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(240, 54)
    b.add_theme_font_size_override("font_size", 20)
    parent.add_child(b)
    return b


func _build_death_panel() -> void:
    var parts: Array = _make_overlay()
    _death_panel = parts[0]
    var box: VBoxContainer = parts[1]
    var title := _make_label(box, "You died", 36)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_color_override("font_color", Color(0.9, 0.25, 0.25))
    _death_info = _make_label(box, "", 18)
    _death_info.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _respawn_btn = _make_button(box, "Respawn at castle")
    _respawn_btn.pressed.connect(func() -> void: respawn_requested.emit())


func _build_pause_panel() -> void:
    var parts: Array = _make_overlay()
    _pause_panel = parts[0]
    var box: VBoxContainer = parts[1]
    var title := _make_label(box, "Paused", 36)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    _make_button(box, "Resume").pressed.connect(func() -> void: resume_requested.emit())
    _make_button(box, "Save game").pressed.connect(func() -> void: save_requested.emit())
    _make_button(box, "Save and quit to menu").pressed.connect(func() -> void: menu_requested.emit())


func _on_wallet_changed(_id: int, _amount: int) -> void:
    _refresh_resources()


func _on_inventory_changed(_id: int) -> void:
    _refresh_resources()


func _refresh_resources() -> void:
    _gold_label.text = "Gold: %d" % GameState.get_gold()
    _wood_label.text = "Wood: %d  (kingdom: %d)" % [GameState.get_item("wood"), int(GameState.kingdom_resources.get("wood", 0))]
