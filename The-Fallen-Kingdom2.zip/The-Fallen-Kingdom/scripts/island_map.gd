class_name IslandMap
extends RefCounted
## Procedural, seed-based island shape. The same world seed always gives the same
## coastline, so only the seed has to be saved (or synced in multiplayer).
## Field value v: > 0 land, 0..0.1 beach, > 0.1 grass, < 0 sea.

const RES: int = 192
const BEACH_END: float = 0.1

var world_size: Vector2 = Vector2(2400, 2400)
var texture: ImageTexture
var center_pos: Vector2 = Vector2.ZERO
var far_inland_pos: Vector2 = Vector2.ZERO  ## good spot for the Zombie Castle

var _vals: PackedFloat32Array = PackedFloat32Array()


func build(world_seed: int, size: Vector2) -> void:
    world_size = size
    var noise := FastNoiseLite.new()
    noise.seed = world_seed
    noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
    noise.fractal_type = FastNoiseLite.FRACTAL_FBM
    noise.fractal_octaves = 4
    noise.frequency = 1.0
    var rng := RandomNumberGenerator.new()
    rng.seed = world_seed
    var stretch := Vector2(rng.randf_range(0.9, 1.3), rng.randf_range(0.9, 1.3))
    var ox: float = rng.randf_range(-50.0, 50.0)
    var oy: float = rng.randf_range(-50.0, 50.0)

    _vals.resize(RES * RES)
    for y in RES:
        for x in RES:
            var p := Vector2(float(x) / float(RES - 1) * 2.0 - 1.0, float(y) / float(RES - 1) * 2.0 - 1.0)
            var n: float = noise.get_noise_2d(p.x * 2.2 + ox, p.y * 2.2 + oy)
            var r: float = (p * stretch).length()
            var v: float = 0.78 - r + n * 0.4
            var edge: float = maxf(absf(p.x), absf(p.y))
            v -= smoothstep(0.72, 0.98, edge) * 1.6
            _vals[y * RES + x] = v

    _keep_main_island()
    _find_far_inland()
    _make_texture()
    center_pos = size / 2.0


## Removes land that is not connected to the island centre (tiny islets).
func _keep_main_island() -> void:
    var seen := PackedByteArray()
    seen.resize(RES * RES)
    var stack: Array[int] = [(RES / 2) * RES + RES / 2]
    while not stack.is_empty():
        var i: int = stack.pop_back()
        if seen[i] == 1 or _vals[i] <= 0.0:
            continue
        seen[i] = 1
        var x: int = i % RES
        var y: int = i / RES
        if x > 0: stack.append(i - 1)
        if x < RES - 1: stack.append(i + 1)
        if y > 0: stack.append(i - RES)
        if y < RES - 1: stack.append(i + RES)
    for i in RES * RES:
        if seen[i] == 0 and _vals[i] > -0.2:
            _vals[i] = -0.2


func _find_far_inland() -> void:
    var best: float = -1.0
    var mid := Vector2(RES / 2.0, RES / 2.0)
    for y in RES:
        for x in RES:
            if _vals[y * RES + x] > 0.28:
                var d: float = Vector2(x, y).distance_to(mid)
                if d > best:
                    best = d
                    far_inland_pos = Vector2(x, y) / float(RES - 1) * world_size


func _make_texture() -> void:
    var img := Image.create(RES, RES, false, Image.FORMAT_RGBA8)
    for y in RES:
        for x in RES:
            var v: float = _vals[y * RES + x]
            img.set_pixel(x, y, Color(clampf(v * 0.5 + 0.5, 0.0, 1.0), 0.0, 0.0, 1.0))
    texture = ImageTexture.create_from_image(img)


## Bilinear field value at a world position (very negative outside the world).
func sample(pos: Vector2) -> float:
    var g: Vector2 = pos / world_size * float(RES - 1)
    if g.x < 0.0 or g.y < 0.0 or g.x > RES - 1 or g.y > RES - 1:
        return -1.0
    var x0: int = mini(int(g.x), RES - 2)
    var y0: int = mini(int(g.y), RES - 2)
    var fx: float = g.x - float(x0)
    var fy: float = g.y - float(y0)
    var a: float = lerpf(_vals[y0 * RES + x0], _vals[y0 * RES + x0 + 1], fx)
    var b: float = lerpf(_vals[(y0 + 1) * RES + x0], _vals[(y0 + 1) * RES + x0 + 1], fx)
    return lerpf(a, b, fy)


func is_walkable(pos: Vector2) -> bool:
    return sample(pos) > 0.0


## Returns where something moving from `from` to `to` may actually end up (no swimming).
func constrain(from: Vector2, to: Vector2) -> Vector2:
    if is_walkable(to):
        return to
    var tx := Vector2(to.x, from.y)
    if is_walkable(tx):
        return tx
    var ty := Vector2(from.x, to.y)
    if is_walkable(ty):
        return ty
    return from


## Random point on land with field value >= min_v (deterministic for a given rng).
func random_land_point(rng: RandomNumberGenerator, min_v: float, margin: float = 40.0) -> Vector2:
    for i in 200:
        var p := Vector2(rng.randf_range(margin, world_size.x - margin), rng.randf_range(margin, world_size.y - margin))
        if sample(p) >= min_v:
            return p
    return center_pos
