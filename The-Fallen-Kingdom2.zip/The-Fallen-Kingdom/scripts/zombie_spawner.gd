class_name ZombieSpawner
extends Node
## Spawns zombies from the Zombie Castle using a fixed-size object pool.

signal zombie_killed(pos: Vector2)

const ZOMBIE_SCENE: PackedScene = preload("res://scenes/zombie.tscn")

var _pool: Array = []
var _enemy_castle: Node2D
var _timer: float = 4.0


func setup(entities: Node2D, enemy_castle: Node2D, kingdom_castle: Node2D) -> void:
    _enemy_castle = enemy_castle
    var n: int = maxi(GameConfig.zombie_cap_day, GameConfig.zombie_cap_night)
    for i in n:
        var z := ZOMBIE_SCENE.instantiate() as Zombie
        z.kingdom_castle = kingdom_castle
        z.killed.connect(_on_killed)
        entities.add_child(z)
        _pool.append(z)


func _process(delta: float) -> void:
    _timer -= delta
    if _timer > 0.0 or _enemy_castle == null:
        return
    var night: bool = GameState.is_night
    _timer = GameConfig.zombie_spawn_interval_night if night else GameConfig.zombie_spawn_interval_day
    var cap: int = GameConfig.zombie_cap_night if night else GameConfig.zombie_cap_day
    var active_count: int = 0
    var free_z: Zombie = null
    for z in _pool:
        if z.active:
            active_count += 1
        elif free_z == null:
            free_z = z
    if free_z == null or active_count >= cap:
        return
    var offset := Vector2(randf_range(-50.0, 50.0), randf_range(44.0, 80.0))
    free_z.activate(_enemy_castle.global_position + offset)


func _on_killed(z: Zombie) -> void:
    zombie_killed.emit(z.global_position)
