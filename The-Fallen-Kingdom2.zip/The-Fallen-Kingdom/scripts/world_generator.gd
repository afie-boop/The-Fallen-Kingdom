class_name WorldGenerator
extends RefCounted
## Deterministic world population on top of the island map. The same seed always
## gives the same trees and ruins, so only the seed and the removed tree ids are saved.

const TREE_SCENE: PackedScene = preload("res://scenes/tree.tscn")
const RUIN_SCENE: PackedScene = preload("res://scenes/ruin.tscn")


static func _blocked(p: Vector2, avoid: Array) -> bool:
    for a in avoid:
        var ad: Dictionary = a
        if p.distance_to(ad["pos"]) < float(ad["r"]):
            return true
    return false


## avoid: Array of {"pos": Vector2, "r": float}. Trees only grow on the grass (not beach/sea).
static func spawn_trees(parent: Node2D, island: IslandMap, world_seed: int, count: int, avoid: Array, removed: Array) -> int:
    var rng := RandomNumberGenerator.new()
    rng.seed = world_seed
    var placed: Array[Vector2] = []
    var spawned: int = 0
    for i in count * 3:
        if placed.size() >= count:
            break
        # Always consume the same random numbers per index so removals never shift later trees.
        var p: Vector2 = Vector2(
            rng.randf_range(40.0, island.world_size.x - 40.0),
            rng.randf_range(60.0, island.world_size.y - 30.0))
        if island.sample(p) < 0.16 or _blocked(p, avoid):
            continue
        var too_close: bool = false
        for q in placed:
            if p.distance_to(q) < 34.0:
                too_close = true
                break
        if too_close:
            continue
        placed.append(p)
        if removed.has(i):
            continue
        var t := TREE_SCENE.instantiate() as ChoppableTree
        t.tree_id = i
        t.position = p
        parent.add_child(t)
        spawned += 1
    return spawned


## Scatters ruined houses on the grass. Returns their positions.
static func spawn_ruins(parent: Node2D, island: IslandMap, world_seed: int, count: int, avoid: Array) -> Array[Vector2]:
    var rng := RandomNumberGenerator.new()
    rng.seed = world_seed + 7919
    var spots: Array[Vector2] = []
    var tries: int = 0
    while spots.size() < count and tries < 400:
        tries += 1
        var p: Vector2 = island.random_land_point(rng, 0.25, 120.0)
        if _blocked(p, avoid):
            continue
        var far_enough: bool = true
        for q in spots:
            if p.distance_to(q) < 260.0:
                far_enough = false
                break
        if not far_enough:
            continue
        spots.append(p)
        var r := RUIN_SCENE.instantiate() as RuinProp
        r.variant = spots.size() - 1
        r.position = p
        parent.add_child(r)
    return spots
