class_name VirtualJoystick
extends Control
## Floating on-screen joystick. A visible home base sits in the bottom-left corner;
## touching anywhere in the left half of the screen moves the stick under your thumb.
## Raw touch events are used so it works together with the buttons (multi-touch).

const RADIUS: float = 72.0
const DEADZONE: float = 0.15
const MOUSE_ID: int = 99

var value: Vector2 = Vector2.ZERO
var _active_id: int = -1
var home: Vector2 = Vector2(110, 110)  ## idle base position (local); set by the HUD layout
var _base_global: Vector2 = Vector2.ZERO


func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE


func _zone() -> Rect2:
    # The HUD sizes this control to the lower-left touch area of the screen.
    return get_global_rect()


func _input(event: InputEvent) -> void:
    if not is_visible_in_tree():
        return
    if event is InputEventScreenTouch:
        var st := event as InputEventScreenTouch
        if st.pressed and _active_id == -1 and _zone().has_point(st.position):
            _begin(st.index, st.position)
        elif not st.pressed and st.index == _active_id:
            _release()
    elif event is InputEventScreenDrag:
        var sd := event as InputEventScreenDrag
        if sd.index == _active_id:
            _update(sd.position)
    elif not DisplayServer.is_touchscreen_available():
        if event is InputEventMouseButton:
            var mb := event as InputEventMouseButton
            if mb.button_index == MOUSE_BUTTON_LEFT:
                if mb.pressed and _active_id == -1 and _zone().has_point(mb.position):
                    _begin(MOUSE_ID, mb.position)
                elif not mb.pressed and _active_id == MOUSE_ID:
                    _release()
        elif event is InputEventMouseMotion and _active_id == MOUSE_ID:
            _update((event as InputEventMouseMotion).position)


func _begin(id: int, pos: Vector2) -> void:
    _active_id = id
    var z: Rect2 = _zone()
    _base_global = Vector2(
        clampf(pos.x, z.position.x + RADIUS, z.end.x - RADIUS),
        clampf(pos.y, z.position.y + RADIUS, z.end.y - RADIUS))
    _update(pos)


func _update(global_pos: Vector2) -> void:
    var v: Vector2 = ((global_pos - _base_global) / RADIUS).limit_length(1.0)
    value = Vector2.ZERO if v.length() < DEADZONE else v
    queue_redraw()


func _release() -> void:
    _active_id = -1
    value = Vector2.ZERO
    queue_redraw()


func _draw() -> void:
    var active: bool = _active_id != -1
    var c: Vector2 = (_base_global - global_position) if active else home
    var a: float = 1.0 if active else 0.75
    draw_circle(c, RADIUS, Color(0, 0, 0, 0.38 * a))
    draw_arc(c, RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.8 * a), 3.0)
    for dir in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
        var d: Vector2 = dir
        var tip: Vector2 = c + d * (RADIUS - 10.0)
        var side: Vector2 = Vector2(-d.y, d.x) * 6.0
        draw_colored_polygon(PackedVector2Array([tip, tip - d * 10.0 + side, tip - d * 10.0 - side]), Color(1, 1, 1, 0.55 * a))
    var knob: Vector2 = c + value * RADIUS * 0.7
    draw_circle(knob, 30.0, Color(1, 1, 1, 0.5 * a))
    draw_arc(knob, 30.0, 0.0, TAU, 32, Color(1, 1, 1, 0.95 * a), 3.0)
