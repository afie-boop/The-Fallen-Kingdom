class_name PixelArt
extends RefCounted
## Procedurally generated original pixel art (no external image files needed).
## Sprites are anchored at the bottom-centre, so a node's origin is its "feet".

static var _cache: Dictionary = {}


static func get_tex(key: String) -> Texture2D:
    if _cache.has(key):
        return _cache[key]
    var tex := ImageTexture.create_from_image(_build(key))
    _cache[key] = tex
    return tex


## Loads an imported image from res:// (cached). Falls back to a magenta
## placeholder if the file is missing so the game never crashes on a bad path.
static func file_tex(path: String) -> Texture2D:
    if _cache.has(path):
        return _cache[path]
    var tex: Texture2D
    if ResourceLoader.exists(path):
        tex = load(path) as Texture2D
    if tex == null:
        push_warning("PixelArt: missing texture %s" % path)
        tex = ImageTexture.create_from_image(_fallback())
    _cache[path] = tex
    return tex


const TREE_COUNT: int = 9
const RUIN_COUNT: int = 5
const CHAR_COUNT: int = 11


static func tree_tex(i: int) -> Texture2D:
    return file_tex("res://assets/trees/tree_%02d.png" % (posmod(i, TREE_COUNT) + 1))


static func ruin_tex(i: int) -> Texture2D:
    return file_tex("res://assets/buildings/ruin_%d.png" % (posmod(i, RUIN_COUNT) + 1))


static func char_tex(i: int) -> Texture2D:
    return file_tex("res://assets/characters/char_%02d.png" % (posmod(i - 1, CHAR_COUNT) + 1))


static func zombie_tex() -> Texture2D:
    return file_tex("res://assets/characters/zombie_01.png")


static func make_sprite_tex(t: Texture2D) -> Sprite2D:
    var s := Sprite2D.new()
    s.texture = t
    s.centered = false
    s.offset = Vector2(-t.get_width() / 2.0, -t.get_height())
    return s


static func make_sprite(key: String) -> Sprite2D:
    var s := Sprite2D.new()
    var t: Texture2D = get_tex(key)
    s.texture = t
    s.centered = false
    s.offset = Vector2(-t.get_width() / 2.0, -t.get_height())
    return s


static func _build(key: String) -> Image:
    if key == "ground":
        return _ground()
    if key == "tree":
        return _tree()
    if key == "castle":
        return _castle()
    if key == "enemy_castle":
        return _enemy_castle()
    if key == "coin":
        return _coin()
    if key.begins_with("player_"):
        var p: PackedStringArray = key.split("_")
        if p.size() == 3:
            return _player(int(p[1]), int(p[2]))
    if key.begins_with("zombie_"):
        var z: PackedStringArray = key.split("_")
        if z.size() == 2:
            return _zombie(int(z[1]))
    push_warning("PixelArt: unknown texture key '%s'" % key)
    return _fallback()


# --- drawing helpers -------------------------------------------------------

static func _new(w: int, h: int) -> Image:
    var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
    img.fill(Color(0, 0, 0, 0))
    return img


static func _px(img: Image, x: int, y: int, c: Color) -> void:
    if x >= 0 and y >= 0 and x < img.get_width() and y < img.get_height():
        img.set_pixel(x, y, c)


static func _rect(img: Image, x: int, y: int, w: int, h: int, c: Color) -> void:
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            _px(img, xx, yy, c)


static func _disc(img: Image, cx: int, cy: int, r: int, c: Color) -> void:
    for yy in range(cy - r, cy + r + 1):
        for xx in range(cx - r, cx + r + 1):
            if (xx - cx) * (xx - cx) + (yy - cy) * (yy - cy) <= r * r:
                _px(img, xx, yy, c)


static func _fallback() -> Image:
    var img := _new(16, 16)
    for y in 16:
        for x in 16:
            _px(img, x, y, Color(1, 0, 1) if (x / 4 + y / 4) % 2 == 0 else Color(0, 0, 0))
    return img


# --- sprites ---------------------------------------------------------------

static func _ground() -> Image:
    var img := _new(32, 32)
    var base := Color(0.27, 0.48, 0.24)
    img.fill(base)
    var rng := RandomNumberGenerator.new()
    rng.seed = 1234
    for i in 100:
        var shade: float = rng.randf_range(-0.05, 0.06)
        _px(img, rng.randi() % 32, rng.randi() % 32, Color(base.r + shade, base.g + shade * 1.4, base.b + shade))
    for i in 14:
        var x: int = rng.randi() % 32
        var y: int = 1 + rng.randi() % 30
        _px(img, x, y, Color(0.2, 0.38, 0.19))
        _px(img, x, y - 1, Color(0.33, 0.56, 0.28))
    for i in 3:
        _px(img, rng.randi() % 32, rng.randi() % 32, Color(0.95, 0.9, 0.4))
    return img


static func _player(dir: int, frame: int) -> Image:
    # dir: 0 down, 1 up, 2 left, 3 right. frame: 0 idle, 1/2 walk.
    var img := _new(16, 16)
    var skin := Color(0.93, 0.74, 0.58)
    var hair := Color(0.35, 0.22, 0.12)
    var tunic := Color(0.2, 0.38, 0.75)
    var tunic_d := Color(0.14, 0.27, 0.55)
    var boots := Color(0.25, 0.17, 0.1)
    var eye := Color(0.1, 0.1, 0.15)
    _rect(img, 3, 14, 10, 2, Color(0, 0, 0, 0.28))
    var lh_l: int = 3
    var lh_r: int = 3
    if frame == 1:
        lh_r = 2
    elif frame == 2:
        lh_l = 2
    _rect(img, 5, 14 - lh_l, 2, lh_l, boots)
    _rect(img, 9, 14 - lh_r, 2, lh_r, boots)
    var side: bool = dir >= 2
    var bx: int = 5 if side else 4
    var bw: int = 6 if side else 8
    _rect(img, bx, 6, bw, 5, tunic)
    _rect(img, bx, 6, bw, 1, tunic_d)
    _rect(img, bx, 10, bw, 1, boots)
    if side:
        _rect(img, 7, 7, 2, 4, tunic_d)
    else:
        _rect(img, 3, 7, 1, 4, tunic_d)
        _rect(img, 12, 7, 1, 4, tunic_d)
    _rect(img, 5, 1, 6, 5, skin)
    if dir == 1:
        _rect(img, 5, 1, 6, 5, hair)
    else:
        _rect(img, 5, 1, 6, 2, hair)
    if dir == 0:
        _px(img, 6, 3, eye)
        _px(img, 9, 3, eye)
    elif dir == 2:
        _px(img, 6, 3, eye)
        _rect(img, 9, 1, 2, 4, hair)
    elif dir == 3:
        _px(img, 9, 3, eye)
        _rect(img, 5, 1, 2, 4, hair)
    return img


static func _zombie(frame: int) -> Image:
    var img := _new(16, 16)
    var skin := Color(0.45, 0.62, 0.38)
    var skin_d := Color(0.32, 0.46, 0.28)
    var cloth := Color(0.38, 0.33, 0.3)
    var blood := Color(0.6, 0.1, 0.1)
    var legs := Color(0.22, 0.2, 0.18)
    _rect(img, 3, 14, 10, 2, Color(0, 0, 0, 0.28))
    var lh_l: int = 3
    var lh_r: int = 3
    if frame == 1:
        lh_l = 2
    _rect(img, 5, 14 - lh_l, 2, lh_l, legs)
    _rect(img, 9, 14 - lh_r, 2, lh_r, legs)
    _rect(img, 4, 6, 8, 5, cloth)
    _rect(img, 5, 7, 2, 2, blood)
    _px(img, 10, 11, cloth)
    var ay: int = 6 if frame == 1 else 7
    _rect(img, 2, ay, 2, 4, skin)
    _rect(img, 12, ay, 2, 4, skin)
    _rect(img, 2, ay + 3, 2, 1, skin_d)
    _rect(img, 12, ay + 3, 2, 1, skin_d)
    _rect(img, 5, 1, 6, 5, skin)
    _rect(img, 5, 1, 6, 1, skin_d)
    _px(img, 6, 3, Color(0.9, 0.1, 0.1))
    _px(img, 9, 3, Color(0.9, 0.1, 0.1))
    _rect(img, 7, 5, 2, 1, Color(0.15, 0.1, 0.1))
    return img


static func _tree() -> Image:
    var img := _new(24, 32)
    var trunk := Color(0.38, 0.25, 0.14)
    var trunk_d := Color(0.28, 0.18, 0.1)
    _rect(img, 6, 29, 12, 3, Color(0, 0, 0, 0.25))
    _rect(img, 10, 18, 4, 12, trunk)
    _rect(img, 12, 18, 2, 12, trunk_d)
    _disc(img, 12, 12, 10, Color(0.12, 0.34, 0.16))
    _disc(img, 8, 14, 7, Color(0.17, 0.43, 0.2))
    _disc(img, 16, 14, 7, Color(0.17, 0.43, 0.2))
    _disc(img, 12, 9, 7, Color(0.22, 0.52, 0.24))
    _disc(img, 9, 8, 3, Color(0.3, 0.62, 0.3))
    return img


static func _castle() -> Image:
    var img := _new(64, 64)
    var stone := Color(0.6, 0.6, 0.66)
    var stone_d := Color(0.42, 0.42, 0.5)
    var stone_l := Color(0.72, 0.72, 0.78)
    var dark := Color(0.12, 0.1, 0.16)
    _rect(img, 2, 60, 60, 4, Color(0, 0, 0, 0.25))
    _rect(img, 10, 26, 44, 34, stone)
    for row in 6:
        var y: int = 28 + row * 6
        _rect(img, 10, y, 44, 1, stone_d)
        var off: int = 0 if row % 2 == 0 else 5
        for x in range(10 + off, 54, 10):
            _rect(img, x, y, 1, 6, stone_d)
    for x in range(10, 54, 8):
        _rect(img, x, 22, 5, 4, stone)
    for tx in [0, 50]:
        _rect(img, tx, 12, 14, 48, stone_l)
        _rect(img, tx + 12, 12, 2, 48, stone_d)
        for by in range(16, 60, 6):
            _rect(img, tx, by, 14, 1, stone_d)
        for bx in range(tx, tx + 14, 5):
            _rect(img, bx, 8, 3, 4, stone_l)
        _rect(img, tx + 5, 24, 4, 7, dark)
    _rect(img, 24, 10, 16, 16, stone)
    for bx in range(24, 40, 5):
        _rect(img, bx, 7, 3, 3, stone)
    _rect(img, 28, 14, 3, 5, dark)
    _rect(img, 33, 14, 3, 5, dark)
    _rect(img, 31, 0, 1, 8, Color(0.42, 0.29, 0.16))
    _rect(img, 32, 1, 9, 5, Color(0.75, 0.2, 0.18))
    _rect(img, 25, 40, 14, 20, dark)
    _disc(img, 32, 40, 7, dark)
    return img


static func _enemy_castle() -> Image:
    var img := _new(64, 64)
    var stone := Color(0.28, 0.24, 0.34)
    var stone_d := Color(0.18, 0.15, 0.23)
    var stone_l := Color(0.38, 0.33, 0.45)
    var glow := Color(0.45, 1.0, 0.4)
    var dark := Color(0.06, 0.04, 0.09)
    _rect(img, 2, 60, 60, 4, Color(0, 0, 0, 0.35))
    _rect(img, 8, 28, 48, 32, stone)
    for row in 5:
        _rect(img, 8, 30 + row * 6, 48, 1, stone_d)
    for tx in [2, 48]:
        _rect(img, tx, 14, 14, 46, stone_l)
        _rect(img, tx + 11, 14, 3, 46, stone_d)
        for sx in range(tx, tx + 14, 4):
            _rect(img, sx, 8, 2, 6, stone_l)
        _rect(img, tx + 5, 26, 4, 6, glow)
    _rect(img, 22, 12, 20, 18, stone)
    for sx in range(22, 42, 4):
        _rect(img, sx, 5, 2, 7, stone)
    _rect(img, 28, 16, 3, 5, glow)
    _rect(img, 34, 16, 3, 5, glow)
    _rect(img, 24, 40, 16, 20, dark)
    _disc(img, 32, 40, 8, dark)
    _rect(img, 29, 44, 2, 2, glow)
    _rect(img, 34, 44, 2, 2, glow)
    return img


static func _coin() -> Image:
    var img := _new(8, 8)
    _disc(img, 4, 4, 3, Color(0.7, 0.5, 0.1))
    _disc(img, 4, 4, 2, Color(1.0, 0.82, 0.2))
    _px(img, 3, 3, Color(1.0, 0.96, 0.7))
    return img
